# Tier 1 batch

- Date: 2026-09-03
- Commit: e3920476c4ab13c2962c7a27372e1c0d687f7ab9
- Seeds: 42 43 44 | Depths: 11 14 18 | n_shuffles: 5 | gates: global raw
- Denominators: sd,fixed,iqr,rank
- Stages run: 1

## Mean struct_delta by denominator

| condition | arm | layer | sd | fixed | iqr | rank | self-check |
|---|---|---:|---:|---:|---:|---:|---|
| outputs_ctrl | ckpt_clm_s42 | 11 | +0.00172 | +0.00021 | +0.00130 | +0.00151 | see log |
| outputs_ctrl | ckpt_clm_s42 | 14 | +0.00114 | +0.00012 | +0.00079 | +0.00031 | see log |
| outputs_ctrl | ckpt_clm_s42 | 18 | +0.00462 | +0.00094 | +0.00425 | +0.00392 | see log |
| outputs_ctrl | ckpt_clm_s43 | 11 | +0.00189 | +0.00037 | +0.00179 | +0.00051 | see log |
| outputs_ctrl | ckpt_clm_s43 | 14 | +0.00240 | +0.00044 | +0.00223 | +0.00072 | see log |
| outputs_ctrl | ckpt_clm_s43 | 18 | +0.00481 | +0.00109 | +0.00469 | +0.00357 | see log |
| outputs_ctrl | ckpt_clm_s44 | 11 | +0.00124 | +0.00031 | +0.00109 | +0.00040 | see log |
| outputs_ctrl | ckpt_clm_s44 | 14 | +0.00079 | +0.00010 | +0.00065 | +0.00012 | see log |
| outputs_ctrl | ckpt_clm_s44 | 18 | +0.00297 | +0.00061 | +0.00282 | +0.00164 | see log |
| outputs_ctrl | ckpt_mlm_s42_token | 11 | +0.01781 | +0.00542 | +0.01549 | +0.01191 | see log |
| outputs_ctrl | ckpt_mlm_s42_token | 14 | +0.01598 | +0.00432 | +0.01096 | +0.01805 | see log |
| outputs_ctrl | ckpt_mlm_s42_token | 18 | +0.01368 | +0.00311 | +0.01053 | +0.00969 | see log |
| outputs_ctrl | ckpt_mlm_s43_token | 11 | +0.01844 | +0.00436 | +0.01329 | +0.01807 | see log |
| outputs_ctrl | ckpt_mlm_s43_token | 14 | +0.01612 | +0.00417 | +0.01089 | +0.01795 | see log |
| outputs_ctrl | ckpt_mlm_s43_token | 18 | +0.01497 | +0.00323 | +0.01072 | +0.01857 | see log |
| outputs_ctrl | ckpt_mlm_s44_token | 11 | +0.02017 | +0.00501 | +0.01660 | +0.01628 | see log |
| outputs_ctrl | ckpt_mlm_s44_token | 14 | +0.01790 | +0.00454 | +0.01174 | +0.01723 | see log |
| outputs_ctrl | ckpt_mlm_s44_token | 18 | +0.01387 | +0.00320 | +0.01017 | +0.01282 | see log |
| outputs_ctrl_shuf | ckpt_clm_s42 | 11 | +0.04546 | +0.00617 | +0.03521 | +0.04556 | see log |
| outputs_ctrl_shuf | ckpt_clm_s42 | 14 | +0.05288 | +0.00689 | +0.04416 | +0.05130 | see log |
| outputs_ctrl_shuf | ckpt_clm_s42 | 18 | +0.05667 | +0.00565 | +0.04803 | +0.05586 | see log |
| outputs_ctrl_shuf | ckpt_clm_s43 | 11 | +0.05197 | +0.00703 | +0.04252 | +0.05787 | see log |
| outputs_ctrl_shuf | ckpt_clm_s43 | 14 | +0.05463 | +0.00676 | +0.04635 | +0.05778 | see log |
| outputs_ctrl_shuf | ckpt_clm_s43 | 18 | +0.04959 | +0.00528 | +0.04305 | +0.05294 | see log |
| outputs_ctrl_shuf | ckpt_clm_s44 | 11 | +0.05185 | +0.00693 | +0.04100 | +0.05882 | see log |
| outputs_ctrl_shuf | ckpt_clm_s44 | 14 | +0.05560 | +0.00686 | +0.04571 | +0.05987 | see log |
| outputs_ctrl_shuf | ckpt_clm_s44 | 18 | +0.04947 | +0.00514 | +0.04174 | +0.05412 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s42_token | 11 | +0.03340 | +0.00609 | +0.02614 | +0.02886 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s42_token | 14 | +0.02762 | +0.00574 | +0.02015 | +0.01827 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s42_token | 18 | +0.02651 | +0.00532 | +0.01680 | +0.02254 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s43_token | 11 | +0.02966 | +0.00538 | +0.02059 | +0.03423 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s43_token | 14 | +0.02422 | +0.00512 | +0.01665 | +0.02877 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s43_token | 18 | +0.02145 | +0.00484 | +0.01422 | +0.02221 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s44_token | 11 | +0.02635 | +0.00651 | +0.02137 | +0.02207 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s44_token | 14 | +0.02726 | +0.00630 | +0.01894 | +0.02488 | see log |
| outputs_ctrl_shuf | ckpt_mlm_s44_token | 18 | +0.02924 | +0.00597 | +0.01705 | +0.02622 | see log |

## d_struct cells

- outputs_ctrl_ckpt_clm_s42_L11.csv
- outputs_ctrl_ckpt_clm_s42_L11_gate-global.csv
- outputs_ctrl_ckpt_clm_s42_L11_gate-raw.csv
- outputs_ctrl_ckpt_clm_s42_L14.csv
- outputs_ctrl_ckpt_clm_s42_L14_gate-global.csv
- outputs_ctrl_ckpt_clm_s42_L14_gate-raw.csv
- outputs_ctrl_ckpt_clm_s42_L18.csv
- outputs_ctrl_ckpt_clm_s42_L18_gate-global.csv
- outputs_ctrl_ckpt_clm_s42_L18_gate-raw.csv
- outputs_ctrl_ckpt_clm_s43_L11_gate-global.csv
- outputs_ctrl_ckpt_clm_s43_L11_gate-raw.csv
- outputs_ctrl_ckpt_clm_s43_L14_gate-global.csv
- outputs_ctrl_ckpt_clm_s43_L14_gate-raw.csv
- outputs_ctrl_ckpt_clm_s43_L18_gate-global.csv
- outputs_ctrl_ckpt_clm_s43_L18_gate-raw.csv
- outputs_ctrl_ckpt_clm_s44_L11_gate-global.csv
- outputs_ctrl_ckpt_clm_s44_L11_gate-raw.csv
- outputs_ctrl_ckpt_clm_s44_L14_gate-global.csv
- outputs_ctrl_ckpt_clm_s44_L14_gate-raw.csv
- outputs_ctrl_ckpt_clm_s44_L18_gate-global.csv
- outputs_ctrl_ckpt_clm_s44_L18_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s42_token_L11.csv
- outputs_ctrl_ckpt_mlm_s42_token_L11_gate-global.csv
- outputs_ctrl_ckpt_mlm_s42_token_L11_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s42_token_L14.csv
- outputs_ctrl_ckpt_mlm_s42_token_L14_gate-global.csv
- outputs_ctrl_ckpt_mlm_s42_token_L14_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s42_token_L18.csv
- outputs_ctrl_ckpt_mlm_s42_token_L18_gate-global.csv
- outputs_ctrl_ckpt_mlm_s42_token_L18_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s43_token_L11_gate-global.csv
- outputs_ctrl_ckpt_mlm_s43_token_L11_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s43_token_L14_gate-global.csv
- outputs_ctrl_ckpt_mlm_s43_token_L14_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s43_token_L18_gate-global.csv
- outputs_ctrl_ckpt_mlm_s43_token_L18_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s44_token_L11_gate-global.csv
- outputs_ctrl_ckpt_mlm_s44_token_L11_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s44_token_L14_gate-global.csv
- outputs_ctrl_ckpt_mlm_s44_token_L14_gate-raw.csv
- outputs_ctrl_ckpt_mlm_s44_token_L18_gate-global.csv
- outputs_ctrl_ckpt_mlm_s44_token_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L11.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L14.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L18.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s42_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s43_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_clm_s44_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L11.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L14.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L18.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s42_token_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s43_token_L18_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L11_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L11_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L14_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L14_gate-raw.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L18_gate-global.csv
- outputs_ctrl_shuf_ckpt_mlm_s44_token_L18_gate-raw.csv
- randominit_s42_ckpt_clm_s42_L11_gate-global.csv
- randominit_s42_ckpt_clm_s42_L11_gate-raw.csv
- randominit_s42_ckpt_clm_s42_L14_gate-global.csv
- randominit_s42_ckpt_clm_s42_L14_gate-raw.csv
- randominit_s42_ckpt_clm_s42_L18_gate-global.csv
- randominit_s42_ckpt_clm_s42_L18_gate-raw.csv
- randominit_s42_ckpt_mlm_s42_token_L11_gate-global.csv
- randominit_s42_ckpt_mlm_s42_token_L11_gate-raw.csv
- randominit_s42_ckpt_mlm_s42_token_L14_gate-global.csv
- randominit_s42_ckpt_mlm_s42_token_L14_gate-raw.csv
- randominit_s42_ckpt_mlm_s42_token_L18_gate-global.csv
- randominit_s42_ckpt_mlm_s42_token_L18_gate-raw.csv
- randominit_s43_ckpt_clm_s42_L11_gate-global.csv
- randominit_s43_ckpt_clm_s42_L11_gate-raw.csv
- randominit_s43_ckpt_clm_s42_L14_gate-global.csv
- randominit_s43_ckpt_clm_s42_L14_gate-raw.csv
- randominit_s43_ckpt_clm_s42_L18_gate-global.csv
- randominit_s43_ckpt_clm_s42_L18_gate-raw.csv
- randominit_s43_ckpt_mlm_s42_token_L11_gate-global.csv
- randominit_s43_ckpt_mlm_s42_token_L11_gate-raw.csv
- randominit_s43_ckpt_mlm_s42_token_L14_gate-global.csv
- randominit_s43_ckpt_mlm_s42_token_L14_gate-raw.csv
- randominit_s43_ckpt_mlm_s42_token_L18_gate-global.csv
- randominit_s43_ckpt_mlm_s42_token_L18_gate-raw.csv
- randominit_s44_ckpt_clm_s42_L11_gate-global.csv
- randominit_s44_ckpt_clm_s42_L11_gate-raw.csv
- randominit_s44_ckpt_clm_s42_L14_gate-global.csv
- randominit_s44_ckpt_clm_s42_L14_gate-raw.csv
- randominit_s44_ckpt_clm_s42_L18_gate-global.csv
- randominit_s44_ckpt_clm_s42_L18_gate-raw.csv
- randominit_s44_ckpt_mlm_s42_token_L11_gate-global.csv
- randominit_s44_ckpt_mlm_s42_token_L11_gate-raw.csv
- randominit_s44_ckpt_mlm_s42_token_L14_gate-global.csv
- randominit_s44_ckpt_mlm_s42_token_L14_gate-raw.csv
- randominit_s44_ckpt_mlm_s42_token_L18_gate-global.csv
- randominit_s44_ckpt_mlm_s42_token_L18_gate-raw.csv
